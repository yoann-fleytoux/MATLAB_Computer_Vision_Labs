Motion sequence: 101 images of a toy house

Image: 480x512 grayscale

